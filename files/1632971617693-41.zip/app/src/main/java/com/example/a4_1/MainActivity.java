package com.example.a4_1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    EditText edit1, edit2;
    Button add, sub, mul, div;
    TextView result;
    String num1, num2;
    Integer res;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("초간단 계산기");

        edit1 = (EditText)findViewById(R.id.edit1);
        edit2 = (EditText)findViewById(R.id.edit2);
        add = (Button)findViewById(R.id.button);
        sub = (Button)findViewById(R.id.button2);
        mul = (Button)findViewById(R.id.button3);
        div = (Button)findViewById(R.id.button4);
        result = (TextView)findViewById(R.id.result);

        add.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View arg0, MotionEvent arg1) {
                num1 = edit1.getText().toString();
                num2 = edit2.getText().toString();
                res = Integer.parseInt(num1) + Integer.parseInt(num2);
                result.setText("계산 결과 : " + res.toString());
                return false;
            }
        });

        sub.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View arg0, MotionEvent arg1) {
                num1 = edit1.getText().toString();
                num2 = edit2.getText().toString();
                res = Integer.parseInt(num1) - Integer.parseInt(num2);
                result.setText("계산 결과 : " + res.toString());
                return false;
            }
        });

        mul.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View arg0, MotionEvent arg1) {
                num1 = edit1.getText().toString();
                num2 = edit2.getText().toString();
                res = Integer.parseInt(num1) * Integer.parseInt(num2);
                result.setText("계산 결과 : " + res.toString());
                return false;
            }
        });

        div.setOnTouchListener(new View.OnTouchListener(){
            @Override
            public boolean onTouch(View arg0, MotionEvent arg1) {
                num1 = edit1.getText().toString();
                num2 = edit2.getText().toString();
                res = Integer.parseInt(num1) / Integer.parseInt(num2);
                result.setText("계산 결과 : " + res.toString());
                return false;
            }
        });
    }
}
