package com.example.a4_4;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

public class MainActivity extends AppCompatActivity {
    TextView text1, text2;
    Switch swAgree;
    RadioGroup rGroup1;
    RadioButton rdoPi, rdoQ, rdoR;
    Button btnend, btnst;
    ImageView img;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("안드로이드 사진 보기");

        text1 = (TextView) findViewById(R.id.Text1);
        swAgree = (Switch) findViewById(R.id.ChkAgree);

        text2 = (TextView) findViewById(R.id.Text2);
        rGroup1 = (RadioGroup) findViewById(R.id.Rgroup1);
        rdoPi = (RadioButton) findViewById(R.id.RdoPi);
        rdoQ = (RadioButton) findViewById(R.id.RdoQ);
        rdoR = (RadioButton) findViewById(R.id.RdoR);

        img = (ImageView) findViewById(R.id.Img);

        btnend = (Button)findViewById(R.id.btnEnd);
        btnst = (Button)findViewById(R.id.btnSt);

        swAgree.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (swAgree.isChecked() == true) {
                    text2.setVisibility(android.view.View.VISIBLE);
                    rGroup1.setVisibility(android.view.View.VISIBLE);
                    btnend.setVisibility(android.view.View.VISIBLE);
                    btnst.setVisibility(android.view.View.VISIBLE);

                } else {
                    text2.setVisibility(android.view.View.INVISIBLE);
                    rGroup1.setVisibility(android.view.View.INVISIBLE);
                    btnend.setVisibility(android.view.View.INVISIBLE);
                    btnst.setVisibility(android.view.View.INVISIBLE);
                    img.setVisibility(android.view.View.INVISIBLE);
                }
            }
        });

        rGroup1.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup radioGroup, int i) {
                if (i == R.id.RdoPi) {
                    img.setImageResource(R.drawable.pi);
                    img.setVisibility(android.view.View.VISIBLE);
                } else if (i == R.id.RdoQ) {
                    img.setImageResource(R.drawable.q);
                    img.setVisibility(android.view.View.VISIBLE);
                } else if (i == R.id.RdoR) {
                    img.setImageResource(R.drawable.r);
                    img.setVisibility(android.view.View.VISIBLE);
                } else {
                    Toast.makeText(getApplicationContext(), "먼저 버전을 선택하세요.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnend.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View arg0) {
                finish();
            }
        });

        btnst.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View v){
                swAgree.setChecked(false);
            }
        });
    }
}
